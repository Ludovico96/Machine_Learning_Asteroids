/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asteroids_application;

/**
 *
 * @author Utente
 */
public class Classifier2 {
    //il primo valore di var0 corrisponde a False, il secondo a True
    public double[] score(double[] input) {
        double[] var0;
        if (input[1] <= -0.3624785244464874) {
            if (input[0] <= -0.0705217681825161) {
                var0 = new double[] {0.002181818181818182, 0.9978181818181818};
            } else {
                var0 = new double[] {0.9862896315338475, 0.013710368466152529};
            }
        } else {
            var0 = new double[] {1.0, 0.0};
        }
        return var0;
    }
}
