/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asteroids_application;

import javafx.animation.FadeTransition;
import javafx.animation.ParallelTransition;
import javafx.animation.SequentialTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @author Utente
 */
public class Asteroids_application extends Application {
    TextField insertAbsoluteMagnitude;
    TextField insertMinimumOrbitIntersection;
    TextField AsteroidID;
    Classifier2 classifier=new Classifier2();
    ClassifierNotNormalized classifierNotNormalized=new ClassifierNotNormalized();
    ConnessionDB cdb=new ConnessionDB();
    Label mostraRisultato;
    ImageView asteroid;
    ImageView hazardousAsteroid;
    ImageView spazio;
    ImageView terra;
    ImageView spazioGioco;
    ImageView astronave;
    ImageView asteroide;
    ImageView laser;
    ImageView esplosione;
    
    Button classify;
    Button search;
    Button back;
    Button insertAsteroid;
    Button insertDB;
    Button simulation;
    Button play;
    Group root;
    
    Label id;
    Label absMagn;
    Label diaMin;
    Label diaMax;
    Label closeApproachDate;
    Label velocity;
    Label missDist;
    Label minimumOrbit;
    Label hazardous;
    VBox vbox;
    VBox vboxInsert;
            
    TextField insert_ID;
    TextField insert_Absolute_Magnitude;
    TextField insert_Dia_Min;
    TextField insert_Dia_Max;
    TextField Insert_Close_Approach_Earth;
    TextField Insert_Velocity;
    TextField Insert_Miss_Dist;
    TextField Insert_Minimum_Orbit_Intersection;
    TextField Insert_Hazardous;
    TextField insertID_simulation;
            
            
            
    public void start(Stage stage) {
        
        spazio=new ImageView("File:\\C:\\prg\\myapps\\Asteroids_application\\src\\asteroids_application\\immagini\\spazio1.jpg");
        spazio.setFitHeight(1000);
        spazio.setFitWidth(1000);
        
        
        
        AsteroidID=new TextField("AsteroidID");
          AsteroidID.setLayoutX(400);
          AsteroidID.setLayoutY(500);
        
         insertAbsoluteMagnitude=new TextField("insertAbsoluteMagnitude");
          insertAbsoluteMagnitude.setLayoutX(250);
          insertAbsoluteMagnitude.setLayoutY(200);
          
          insertMinimumOrbitIntersection=new TextField("insertMinimumOrbitIntersection");
          insertMinimumOrbitIntersection.setLayoutX(550);
          insertMinimumOrbitIntersection.setLayoutY(200);
          
          
          
          classify=new Button("Classify");
          classify.setLayoutX(450);
          classify.setLayoutY(300);
         
          
          
          classify.setOnAction(event->{
              root.getChildren().remove(mostraRisultato);
              try{
              String AbsoluteMagnitude=insertAbsoluteMagnitude.getText();
              String MinimumOrbitIntersection=insertMinimumOrbitIntersection.getText();
              
              double val[]=new double[]{Double.parseDouble(MinimumOrbitIntersection),Double.parseDouble(AbsoluteMagnitude)};
              double[] risultato= classifier.score(val);
             
             if(risultato[0]>0.9){
                 
              mostraRisultato=new Label("Not Hazardous");
              mostraRisultato.setLayoutX(450);
              mostraRisultato.setLayoutY(150);
              asteroid=new ImageView("File:\\C:\\prg\\myapps\\Asteroids_application\\src\\asteroids_application\\immagini\\asteroide8.jpg");
              asteroid.setFitHeight(1000);
              asteroid.setFitWidth(1000);
               back=new Button("back");
              root.getChildren().addAll(asteroid,back);
              back.setOnAction(event1->{
                  root.getChildren().removeAll(asteroid,back,mostraRisultato);
              });
          } else{
              mostraRisultato=new Label("Hazardous");
              mostraRisultato.setLayoutX(450);
              mostraRisultato.setLayoutY(150);
              hazardousAsteroid=new ImageView("File:\\C:\\prg\\myapps\\Asteroids_application\\src\\asteroids_application\\immagini\\asteroide5.jpg");
              hazardousAsteroid.setFitHeight(1000);
              hazardousAsteroid.setFitWidth(1000);
              back=new Button("back");
              root.getChildren().addAll(hazardousAsteroid,back);
              back.setOnAction(event1->{
                  root.getChildren().removeAll(hazardousAsteroid,back,mostraRisultato);
              });
             
             
             }
             mostraRisultato.setStyle("-fx-font-size: 30px; -fx-text-fill: white");
             root.getChildren().add(mostraRisultato);
              }catch(Exception e){
                  System.out.println("classificazione non valida");
              }
              
          });
          
          search=new Button("search");
          search.setLayoutX(450);
          search.setLayoutY(550);
          
          search.setOnAction(event->{
              root.getChildren().remove(vbox);
              cdb.caricaAsteroidi();
              try{
              for(int i=0;i<cdb.listaID.size();i++){
                 
                  if(cdb.listaID.get(i)==Integer.parseInt(AsteroidID.getText())){
                  cdb.caricaParametriAsteroide(Integer.parseInt(AsteroidID.getText()));
                  id=new Label(String.valueOf("Neo Reference ID: "+cdb.listaParametri.get(0).getID()));
                  id.setStyle("-fx-font-size: 17px; -fx-text-fill: white");
                  absMagn=new Label(String.valueOf("Absolute Magnitude: "+cdb.listaParametri.get(0).getAbsoluteMagnitude()+" H"));
                  absMagn.setStyle("-fx-font-size: 17px; -fx-text-fill: white");
                  diaMin=new Label(String.valueOf("Est Dia in KM(min): "+cdb.listaParametri.get(0).geEstDiaKmMin()+" Km"));
                  diaMin.setStyle("-fx-font-size: 17px; -fx-text-fill: white");
                  diaMax=new Label(String.valueOf("Est Dia inKM(max): "+cdb.listaParametri.get(0).getEstDiaKmMax()+" Km"));
                  diaMax.setStyle("-fx-font-size: 17px; -fx-text-fill: white");
                  closeApproachDate=new Label(String.valueOf("Close Approach Date: "+cdb.listaParametri.get(0).getCloseApproachDate()));
                  closeApproachDate.setStyle("-fx-font-size: 17px; -fx-text-fill: white");
                  velocity=new Label(String.valueOf("Relative Velocity KM per sec: "+cdb.listaParametri.get(0).getRelativeVelocityPerSec()+" Km/s"));
                  velocity.setStyle("-fx-font-size: 17px; -fx-text-fill: white");
                  missDist=new Label(String.valueOf("Miss Dist.(Astronomical): "+cdb.listaParametri.get(0).getMissDist()+" au"));
                  missDist.setStyle("-fx-font-size: 17px; -fx-text-fill: white");
                  minimumOrbit=new Label(String.valueOf("Minimum Orbit Intersection: "+cdb.listaParametri.get(0).getMinimumOrbit()+" au"));
                  minimumOrbit.setStyle("-fx-font-size: 17px; -fx-text-fill: white");
                  hazardous=new Label(String.valueOf("Hazardous: "+cdb.listaParametri.get(0).getHazardous()));
                  hazardous.setStyle("-fx-font-size: 17px; -fx-text-fill: white");
                  vbox=new VBox();
                  vbox.setLayoutX(400);
                  vbox.setLayoutY(600);
                  vbox.getChildren().addAll(id,absMagn,diaMin,diaMax,closeApproachDate,velocity,missDist,minimumOrbit,hazardous);
                  root.getChildren().add(vbox);
                }
            }
              }catch(Exception e){
                  System.out.println("ID non valido");
              }
              
          });
          
          insertAsteroid=new Button("insertAsteroid");
          insertAsteroid.setLayoutX(450);
          insertAsteroid.setLayoutY(400);
          insertAsteroid.setOnAction(event->{
             
              
              terra=new ImageView("File:\\C:\\prg\\myapps\\Asteroids_application\\src\\asteroids_application\\immagini\\terra.jpg");
              terra.setFitHeight(1000);
              terra.setFitWidth(1000);
              insert_ID=new TextField("insert_ID");
              insert_Absolute_Magnitude=new TextField("insert_Absolute_Magnitude");
              insert_Dia_Min=new TextField("insert_Dia_Min");
              insert_Dia_Max=new TextField("insert_Dia_Max");
              Insert_Close_Approach_Earth=new TextField("Insert_Close_Approach_Earth");
              Insert_Velocity=new TextField("Insert_Velocity");
              Insert_Miss_Dist=new TextField("Insert_Miss_Dist");
              Insert_Minimum_Orbit_Intersection=new TextField("Insert_Minimum_Orbit_Intersection");
              Insert_Hazardous=new TextField("Insert_Hazardous");
               insertDB=new Button("insertDB");
              vboxInsert=new VBox();
              vboxInsert.getChildren().addAll(insert_ID,insert_Absolute_Magnitude,insert_Dia_Min,insert_Dia_Max,Insert_Close_Approach_Earth,Insert_Velocity,Insert_Miss_Dist,Insert_Minimum_Orbit_Intersection,insertDB);
              vboxInsert.setLayoutX(450);
              vboxInsert.setLayoutY(300);
              
              
              
             
              insertDB.setOnAction(event1->{
                  try{
                  int i=Integer.parseInt(insert_ID.getText());
              double am=Double.parseDouble(insert_Absolute_Magnitude.getText());
              double dmin=Double.parseDouble(insert_Dia_Min.getText());
              double dmax=Double.parseDouble(insert_Dia_Max.getText());
              String cae=Insert_Close_Approach_Earth.getText();
              double v=Double.parseDouble(Insert_Velocity.getText());
              double md=Double.parseDouble(Insert_Miss_Dist.getText());
              double moi=Double.parseDouble(Insert_Minimum_Orbit_Intersection.getText());
             // boolean h=Boolean.parseBoolean(Insert_Hazardous.getText());
              
               double val[]=new double[]{am,moi};
              double[] risultato= classifierNotNormalized.score(val);
              if(risultato[1]>0.9){
                  boolean h=true;
                   cdb.settaParametriAsteroide(i, am, dmin, dmax, cae, v, md, moi, h);
              }else{
                   boolean h=false;
                  cdb.settaParametriAsteroide(i, am, dmin, dmax, cae, v, md, moi, h);
              }
                  
                  
                   }catch(Exception e){
                 System.out.println("Inserimento non valido");
             }
              });
              
             
              
              
               back=new Button("back");
              back.setOnAction(event1->{
                  root.getChildren().removeAll(terra,vboxInsert,back);
              });
              root.getChildren().addAll(terra,vboxInsert,back);
          });
          
          simulation=new Button("Simulation");
          simulation.setLayoutX(450);
          simulation.setLayoutY(850);
          simulation.setOnAction(event->{
              play=new Button("play");
              play.setLayoutX(900);
              play.setLayoutY(50);
               spazioGioco=new ImageView("File:\\C:\\prg\\myapps\\Asteroids_application\\src\\asteroids_application\\immagini\\spazio.jpg");
               spazioGioco.setFitHeight(1000);
               spazioGioco.setFitWidth(1000);
               astronave=new ImageView("File:\\C:\\prg\\myapps\\Asteroids_application\\src\\asteroids_application\\immagini\\astronave.png");
               astronave.setFitHeight(100);
               astronave.setFitWidth(100);
               astronave.setLayoutX(450);
               astronave.setLayoutY(900);
               asteroide=new ImageView("File:\\C:\\prg\\myapps\\Asteroids_application\\src\\asteroids_application\\immagini\\asteroide.png");
               asteroide.setFitHeight(100);
               asteroide.setFitWidth(100);
               asteroide.setLayoutX(450);
               asteroide.setLayoutY(100);
               back=new Button("back");
               insertID_simulation=new TextField("insertID_simulation");
               insertID_simulation.setLayoutX(850);
              
               root.getChildren().addAll(spazioGioco,astronave,asteroide,back,insertID_simulation,play);
               
               play.setOnAction(event1->{
                   try{
                       cdb.caricaParametriAsteroide(Integer.parseInt(insertID_simulation.getText()));
                   
                   
                  
              
              double val[]=new double[]{cdb.listaParametri.get(0).getAbsoluteMagnitude(),cdb.listaParametri.get(0).getMinimumOrbit()};
              double[] risultato= classifierNotNormalized.score(val);
                        
              
               if(risultato[1]>0.9){
                   esplosione=new ImageView("File:\\C:\\prg\\myapps\\Asteroids_application\\src\\asteroids_application\\immagini\\explosion.png");
                   esplosione.setFitHeight(200);
               esplosione.setFitWidth(200);
               esplosione.setLayoutX(400);
               esplosione.setLayoutY(70);
                   
                   laser=new ImageView("File:\\C:\\prg\\myapps\\Asteroids_application\\src\\asteroids_application\\immagini\\laser.png");
                    laser.setFitHeight(50);
               laser.setFitWidth(50);
               laser.setLayoutX(450);
               laser.setLayoutY(850);
               root.getChildren().addAll(laser,esplosione);
               
               TranslateTransition translateTransition=new TranslateTransition(Duration.millis(100), laser);
               translateTransition.setFromY(0);
        translateTransition.setToY(-700);
        
        
        FadeTransition fadeTransition = 
            new FadeTransition(Duration.millis(1000), esplosione);
        fadeTransition.setFromValue(1.0f);
        fadeTransition.setToValue(0.0f);
        fadeTransition.setCycleCount(1);
        
        FadeTransition fadeTransition2 = 
            new FadeTransition(Duration.millis(1000), laser);
        fadeTransition2.setFromValue(1.0f);
        fadeTransition2.setToValue(0.0f);
        fadeTransition2.setCycleCount(1);
        
        FadeTransition fadeTransition3 = 
            new FadeTransition(Duration.millis(1000), asteroide);
        fadeTransition2.setFromValue(1.0f);
        fadeTransition2.setToValue(0.0f);
        fadeTransition2.setCycleCount(1);
        
        ParallelTransition parallelTransition = new ParallelTransition();
        parallelTransition.getChildren().addAll(
                fadeTransition,
                fadeTransition2,
                fadeTransition3
        );
        
                
          SequentialTransition      sequentialTransition = new SequentialTransition();
sequentialTransition.getChildren().addAll(
        
        translateTransition,
        parallelTransition
        );

sequentialTransition.play();
               }
               }catch(Exception e){
                       System.out.println("insert non valido");
                   }
                   
               });
               
             // root.getChildren().addAll(spazioGioco,astronave,asteroide,back,insertID_simulation,play);
              back.setOnAction(event1->{
                  root.getChildren().removeAll(spazioGioco,astronave,asteroide,back,insertID_simulation,play);
              });
          });
          
          root=new Group(spazio,insertAbsoluteMagnitude,insertMinimumOrbitIntersection,classify,AsteroidID,search,insertAsteroid,simulation);
          Scene scene=new Scene(root,1000,1000);     
        stage.setTitle("Asteroids classification");
        stage.setScene(scene);
        stage.show();
         
    }
}
