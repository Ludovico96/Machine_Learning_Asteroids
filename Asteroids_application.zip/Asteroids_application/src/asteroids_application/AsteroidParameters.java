/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asteroids_application;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 *
 * @author Utente
 */
public class AsteroidParameters {
    private final SimpleIntegerProperty id;
    private final SimpleDoubleProperty absoluteMagnitude;
    private final SimpleDoubleProperty estDiaInKmMin;
    private final SimpleDoubleProperty estDiaInKmMax;
    private final SimpleStringProperty closeApproachDate;
    private final SimpleDoubleProperty relativeVelocityKmPerSec;
    private final SimpleDoubleProperty missDist;
    private final SimpleDoubleProperty minimumOrbitIntersection;
    private final SimpleBooleanProperty hazardous;
    
    
    public AsteroidParameters(int i,double am,double edikmin,double edikmax,
        String cad,double rvkps,double md,double moi, boolean h){
        id=new SimpleIntegerProperty(i);
        absoluteMagnitude=new SimpleDoubleProperty(am);
        estDiaInKmMin=new SimpleDoubleProperty(edikmin);
        estDiaInKmMax=new SimpleDoubleProperty(edikmax);
        closeApproachDate=new SimpleStringProperty(cad);
        relativeVelocityKmPerSec=new SimpleDoubleProperty(rvkps);
        missDist=new SimpleDoubleProperty(md);
        minimumOrbitIntersection=new SimpleDoubleProperty(moi);
        hazardous=new SimpleBooleanProperty(h);
    }
    
    public int getID(){
        return id.get();
    }
    public double getAbsoluteMagnitude(){
        return absoluteMagnitude.get();
    }
    public double geEstDiaKmMin(){
        return estDiaInKmMin.get();
    }
    public double getEstDiaKmMax(){
        return estDiaInKmMax.get();
    }
    public String getCloseApproachDate(){
        return closeApproachDate.get();
    }
    public double getRelativeVelocityPerSec(){
        return relativeVelocityKmPerSec.get();
    }
    public double getMissDist(){
        return missDist.get();
    }
    public double getMinimumOrbit(){
        return minimumOrbitIntersection.get();
    }
    public Boolean getHazardous(){
        return hazardous.get();
    }



}

