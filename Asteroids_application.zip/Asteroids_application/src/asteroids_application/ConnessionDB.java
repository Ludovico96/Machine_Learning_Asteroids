/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asteroids_application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Utente
 */
public class ConnessionDB {
    List<AsteroidParameters> listaParametri;
    List<Integer> listaID;
    
    public void settaParametriAsteroide(int id,double am,double edkmin,double 
            edikmax,String cad,double rvkps,double md,double moi, boolean h){
        try(Connection co=DriverManager.getConnection("jdbc:mysql://localhost:3306/asteroid2","root","");
                PreparedStatement ps=co.prepareStatement("INSERT INTO asteroidsparameter2 VALUES(?,?,?,?,?,?,?,?,?)");
                ){
            ps.setInt(1, id);ps.setDouble(2, am);ps.setDouble(3, edkmin);ps.setDouble(4, edikmax);
            ps.setString(5, cad);ps.setDouble(6, rvkps);ps.setDouble(7, md);ps.setDouble(8, moi);
            ps.setBoolean(9, h);
            
            System.out.println("rows affected" +ps.executeUpdate());
        }catch(SQLException e){
            e.getMessage();
        }
    }
    
    public void caricaParametriAsteroide(int id){
        listaParametri=new ArrayList<>();
        try(Connection co=DriverManager.getConnection("jdbc:mysql://localhost:3306/asteroid2","root","");
                PreparedStatement ps=co.prepareStatement("SELECT * FROM asteroidsparameter2 WHERE Neo_Reference_ID= ?");
                        ){
           ps.setInt(1,id);
           ResultSet rs=ps.executeQuery();
           while(rs.next())
               listaParametri.add(new AsteroidParameters(rs.getInt("Neo_Reference_ID"),rs.getDouble("Absolute_Magnitude"),rs.getDouble("Est_Dia_in_KM(min)"),
                       rs.getDouble("Est_Dia_in_KM(max)"),rs.getString("Close_Approach_Date"),rs.getDouble("Relative_Velocity_km_per_sec"),rs.getDouble("Miss_Dist.(Astronomical)"),
                       rs.getDouble("Minimum_Orbit_Intersection"),rs.getBoolean("Hazardous")));
           
       }catch(SQLException e){
            System.out.println("impossibile trovare asteroide nel datatbase");
       }
    }
    
     public void caricaAsteroidi(){
       listaID=new ArrayList<>();
    try(Connection co=DriverManager.getConnection("jdbc:mysql://localhost:3306/asteroid2","root","");
            Statement st=co.createStatement();
            ){
        ResultSet rs=st.executeQuery("SELECT Neo_Reference_ID FROM asteroidsparameter2");
        while(rs.next()){
            listaID.add(new Integer(rs.getInt("Neo_Reference_ID")));
        } 
    } catch(SQLException e){
        e.getMessage();
    }
}
}