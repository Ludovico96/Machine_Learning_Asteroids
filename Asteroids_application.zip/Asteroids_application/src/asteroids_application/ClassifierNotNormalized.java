/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asteroids_application;

/**
 *
 * @author Utente
 */
public class ClassifierNotNormalized {
    //input[0]=absoluteMagnitude
    //input[1]=minimumOrbitIntersection
    //(false,true)
    public double[] score(double[] input) {
        double[] var0;
        if (input[1] <= 0.04976554960012436) {
            if (input[0] <= 22.097925186157227) {
                var0 = new double[] {0.0021660649819494585, 0.9978339350180505};
            } else {
                var0 = new double[] {0.9948186528497409, 0.0051813471502590676};
            }
        } else {
            var0 = new double[] {0.9993804213135068, 0.0006195786864931846};
        }
        return var0;
    }
}
