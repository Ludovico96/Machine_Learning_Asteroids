CREATE DATABASE  IF NOT EXISTS `videogame` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `videogame`;
-- MySQL dump 10.13  Distrib 5.6.17, for Win32 (x86)
--
-- Host: localhost    Database: videogame
-- ------------------------------------------------------
-- Server version	5.6.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `timer`
--

DROP TABLE IF EXISTS `timer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `timer` (
  `user` varchar(45) NOT NULL,
  `time` varchar(1000) NOT NULL,
  `timeMS` varchar(1000) NOT NULL,
  PRIMARY KEY (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timer`
--

LOCK TABLES `timer` WRITE;
/*!40000 ALTER TABLE `timer` DISABLE KEYS */;
INSERT INTO `timer` VALUES ('cuju','0:00:31.4','31400'),('djfb','0:00:06.9','6900'),('g','0:00:05.4','5400'),('h','0:00:07.1','7100'),('l','0:00:11.0','11000'),('lala','0:00:06.8','6800'),('luciano','0:04:04.6','244600'),('lucio','0:00:25.0','25000'),('pg1','0:01:35.3','95300'),('pg10','0:00:09.8','9800'),('pg11','0:00:11.6','11600'),('pg12','0:00:27.5','27500'),('pg13','0:00:02.1','2100'),('pg14','0:00:19.4','19400'),('pg15','0:00:03.0','3000'),('pg16','0:00:38.2','38200'),('pg17','0:00:19.3','19300'),('pg2','0:00:06.5','6500'),('pg20','0:00:09.8','9800'),('pg21','0:00:35.6','35600'),('pg23','0:00:10.2','10200'),('pg3','0:00:18.6','18600'),('pg4','0:00:06.9','6954'),('pg5','0:00:14.4','14418'),('pg6','0:04:09.7','249700'),('pg7','0:00:50.2','50200'),('pg8','0:00:21.1','21100'),('pg9','0:00:06.8','6800'),('player1','0:00:06.4','6400'),('player2','0:00:12.1','12100'),('player3','0:00:22.9','22900'),('player4','0:00:57.1','57100'),('player5','0:00:29.0','29000'),('player6','0:00:20.5','20500'),('player7','0:00:45.7','45700'),('player8','0:02:35.4','155400'),('player9','0:05:08.7','308700'),('prova','0:02:40.2','160200'),('sasageyo','0:00:06.8','6800'),('test','0:02:56.8','176800'),('test1','0:04:54.6','294600'),('test2','0:13:32.8','812800'),('test3','0:00:56.0','56000'),('test4','0:00:00.0','0'),('test5','0:00:04.1','4100');
/*!40000 ALTER TABLE `timer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-30 21:34:16
